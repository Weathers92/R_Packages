##################################
### Round Decimal V2           ###
### Creator: Brandon Weathers  ###
### Date: 10/11/2019           ###
##################################

#' @export

roundDecimal <- function(x, place, method){
  
  if(!(method %in% c("round", "ceiling", "floor", "trunc"))){
    
    require("crayon")
    return(cat(crayon::red('Error: Please specify a type of either \"round\", \"ceiling\", or \"floor\".', sep = "")))
  }
  
  if(method == "round") roundedX <- round(x, place)
  else{
    xAdj <- 10**place
  }
  
  if(method == "ceiling") roundedX <- ceiling(x*xAdj)/xAdj
  
  if(method %in% c("floor", "trunc")) roundedX <- floor(x*xAdj)/xAdj
  
  return(roundedX)
}