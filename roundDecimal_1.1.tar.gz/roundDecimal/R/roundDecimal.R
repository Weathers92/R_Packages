#################################
### Round Decimal             ###
### Creator: Brandon Weathers ###
### Date: 10/11/2019          ###
#################################

#' @export

roundDecimal <- function(x, place, method){
  
  require("stringr")
  
  # Position of decimal place.
  deciPos <- stringr::str_locate(x, "[.]")[,1]
  
  # Position of number to change.
  targetNumPos <- deciPos + place
  
  roundedX <- NULL
  
  if(method == "round") roundedX <- round(x, place)
  else{
    
    # Convert numeric values to character strings.
    roundedX <- as.character(x)
    
    if(method == "ceiling"){
      
      # Extract the number in the decimal place specified by place.
      targetNum <- substring(roundedX, targetNumPos, targetNumPos)
      
      # Determines which targetNums have a value of 9.
      targetNine <- which(targetNum == "9")
      # Determines which targetNums do not have a value of 9.
      notNine <- which(targetNum != "9")
      
      # Round all decimals which have a targetNum of 9 to the specified decimal place.
      roundedX[targetNine] <- as.character(round(x[targetNine], place - 1))
      
      # Increase the targetNums which aren't 9 by one.
      newNum <- as.character(as.numeric(targetNum[notNine])+1)
      
      # Replace the targetNums which aren't 9 with the new number.
      substr(roundedX[notNine], targetNumPos[notNine], targetNumPos[notNine]) <- newNum
      
    }
    
    if(!(method %in% c("round", "ceiling", "floor", "trunc"))){
      
      require("crayon")
      return(cat(crayon::red('Error: Please specify a type of either \"round\", \"ceiling\", or \"floor\".', sep = "")))
    }
  }
  
  roundedX <- as.numeric(substr(roundedX, 1, targetNumPos))
  
  return(roundedX)
}



